This module includes annotations in Java that are used to annotate test suites.
